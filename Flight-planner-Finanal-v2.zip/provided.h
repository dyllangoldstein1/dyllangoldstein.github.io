#ifndef PROVIDED_H
#define PROVIDED_H

#include <string>
#include <vector>

// FlightSegment struct representing one leg of a journey
struct FlightSegment {
    std::string airline_name;
    int flight_number;
    std::string source_airport;
    std::string destination_airport;
    int departure_time;
    int duration;
};

// Itinerary struct representing a complete route
struct Itinerary {
    std::string source_airport;
    std::string destination_airport;
    int total_duration;
    std::vector<FlightSegment> flights;
};

// Abstract base class for FlightManager
class FlightManagerBase {
public:
    virtual ~FlightManagerBase() {}
    virtual bool load_flight_data(const std::string& filename) = 0;
    virtual std::vector<FlightSegment> find_flights(const std::string& source_airport, int start_time, int end_time) const = 0;
};

// Abstract base class for TravelPlanner
class TravelPlannerBase {
private:
    int max_duration = 86400;  // 24 hours in seconds
    int max_layover = 7200;    // 2 hours in seconds
    int min_connection_time = 3600;  // 1 hour in seconds
    
public:
    virtual ~TravelPlannerBase() {}
    
    void set_max_duration(int duration) { max_duration = duration; }
    int get_max_duration() const { return max_duration; }
    
    void set_max_layover(int layover) { max_layover = layover; }
    int get_max_layover() const { return max_layover; }
    
    void set_min_connection_time(int time) { min_connection_time = time; }
    int get_min_connection_time() const { return min_connection_time; }
    
    virtual void add_preferred_airline(const std::string& airline) = 0;
    virtual bool plan_travel(const std::string& source_airport, const std::string& destination_airport, 
                            int start_time, Itinerary& itinerary) const = 0;
};

#endif