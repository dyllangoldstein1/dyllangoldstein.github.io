
## Overview
The Flight Planning System is a C++ application that finds optimal flight routes between airports. Using an A* search algorithm, it generates the most efficient itineraries based on available flights while respecting constraints such as maximum layover time and connection requirements.

## Features
- Load and parse flight schedule data from CSV files
- Find optimal routes between any two airports
- Support for preferred airlines
- Configurable constraints:
  - Maximum total travel duration
  - Maximum layover time
  - Minimum connection time
- Detailed itinerary output with:
  - Flight segments
  - Layover times
  - Departure and arrival times
  - Total journey duration

## Installation

### Prerequisites
- C++ compiler with C++11 support (g++, clang, etc.)
- Make sure all source files are in the same directory:
  - main.cpp
  - fm.cpp
  - tp.cpp
  - fm.h
  - tp.h
  - airport_db.h
  - bstset.h
  - provided.h

### Compilation
```bash
g++ -std=c++11 main.cpp fm.cpp tp.cpp -o flight_planner
```

## Usage
1. Create a flight data file named `flights.txt` in the same directory (see Data File Format)
2. Run the program:
   ```bash
   ./flight_planner
   ```
3. Follow the interactive prompts:
   - Choose whether to specify preferred airlines
   - Enter the source airport code (e.g., HHR)
   - Enter the destination airport code (e.g., PTU)
   - Choose whether to use current time or enter a specific Unix timestamp
4. View the generated itinerary

## Data File Format
The `flights.txt` file should contain flight data in the following comma-separated format:

```
AirlineName,FlightNumber,SourceAirport,DestinationAirport,DepartureTime,ArrivalTime,Duration
```

Example:
```
Desert Jet,1234,HHR,CLD,1736285400,1736288280,2880
Netjets Aviation,5678,CLD,COS,1736294400,1736298420,4020
Air Canada,9101,COS,DEN,1736303700,1736307540,3840
```

Where:
- **AirlineName**: Name of the airline
- **FlightNumber**: Flight number
- **SourceAirport**: Three-letter airport code for departure
- **DestinationAirport**: Three-letter airport code for arrival
- **DepartureTime**: Unix timestamp for departure time
- **ArrivalTime**: Unix timestamp for arrival time
- **Duration**: Flight duration in seconds

## Configuration
The system has three main configuration parameters that can be adjusted in the code:

```cpp
tp.set_max_duration(86400);     // Maximum total journey time (24 hours)
tp.set_max_layover(10000);      // Maximum waiting time at connecting airports (~2.8 hours)
tp.set_min_connection_time(3600); // Minimum required time for connections (1 hour)
```

## Troubleshooting

### No Valid Itinerary Found
If the system can't find a route, check the following:

1. Ensure the airports exist in your flight data file
2. Verify that the flights can be connected with valid layover times
3. Try adjusting the constraints:
   - Increase `max_layover` (currently 10000 seconds or ~2.8 hours)
   - Decrease `min_connection_time` (currently 3600 seconds or 1 hour)

### Time Conversions
To convert between human-readable dates and Unix timestamps:

- **Online converter**: https://www.unixtimestamp.com/
- **From command line**:
  - On Mac: `date -r 1736284400`
  - On Linux: `date -d @1736284400`

## System Architecture
The system consists of these main components:

- **Flight Manager**: Loads and provides access to flight data
- **Travel Planner**: Implements A* search to find optimal routes
- **BSTSet**: Binary search tree for efficient flight lookup
- **AirportDB**: Provides airport information and distance estimates
