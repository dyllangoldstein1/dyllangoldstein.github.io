#include "tp.h"
#include <queue>
#include <map>
#include <chrono>

// Helper struct to store itinerary information during the search
struct ItineraryNode {
  Itinerary itinerary;
  int arrival_time; // Arrival time at the last airport in the itinerary
  std::string current_airport; // Current airport
  int heuristic; // Heuristic value (estimated time to destination)

  // Custom comparison for priority queue (lower cost = higher priority)
  bool operator>(const ItineraryNode& other) const {
    // Total cost = time spent so far + estimated time to destination
    return (arrival_time + heuristic) > (other.arrival_time + other.heuristic);
  }
};

void TravelPlanner::add_preferred_airline(const std::string& airline) {
    preferred_airlines.insert(airline);
}

bool TravelPlanner::plan_travel(const std::string& source_airport, const std::string& destination_airport, 
                              int start_time, Itinerary& itinerary) const {
    std::priority_queue<ItineraryNode, std::vector<ItineraryNode>, std::greater<ItineraryNode>> queue;
    
    ItineraryNode start_node;
    start_node.current_airport = source_airport;
    start_node.arrival_time = start_time;
    start_node.itinerary.source_airport = source_airport;
    start_node.itinerary.destination_airport = destination_airport;
    start_node.itinerary.total_duration = 0;
    start_node.heuristic = estimate_time_to_destination(source_airport, destination_airport);
    queue.push(start_node);
    
    // Track best arrival time at each airport (to avoid cycles)
    std::map<std::string, int> best_times;
    
    // Set initial start time for source airport
    best_times[source_airport] = start_time;
    
    // Add timeout to prevent infinite search
    auto start_time_point = std::chrono::high_resolution_clock::now();
    
    while (!queue.empty()) {
        // Check for timeout (60 seconds)
        auto now = std::chrono::high_resolution_clock::now();
        auto elapsed = std::chrono::duration_cast<std::chrono::seconds>(now - start_time_point).count();
        if (elapsed > 60) {
            return false; // Timeout
        }
        
        ItineraryNode current_node = queue.top();
        queue.pop();
        
        // If we've reached the destination, return the itinerary
        if (current_node.current_airport == destination_airport) {
            itinerary = current_node.itinerary;
            itinerary.total_duration = current_node.arrival_time - start_time;
            return true;
        }
        
        // Calculate departure window for next flights
        int min_departure_time, max_departure_time;
        
        if (current_node.itinerary.flights.empty()) {
            // For first flight from source airport
            min_departure_time = current_node.arrival_time;
            max_departure_time = current_node.arrival_time + get_max_layover();
        } else {
            // For connecting flights
            min_departure_time = current_node.arrival_time + get_min_connection_time();
            max_departure_time = current_node.arrival_time + get_max_layover();
        }
        
        // Get all flights departing from current airport within time window
        std::vector<FlightSegment> flights = flight_manager.find_flights(
            current_node.current_airport, min_departure_time, max_departure_time
        );
        
        // Process each potential flight
        for (const FlightSegment& flight : flights) {
            // Skip if non-preferred airline when we have preferences
            if (!preferred_airlines.empty() && preferred_airlines.find(flight.airline_name) == preferred_airlines.end()) {
                continue;
            }
            
            // Calculate arrival time at next airport
            int next_arrival_time = flight.departure_time + flight.duration;
            
            // Skip if exceeds max duration
            if (next_arrival_time - start_time > get_max_duration()) {
                continue;
            }
            
            // Skip if we've already found a better path to that airport
            if (best_times.find(flight.destination_airport) != best_times.end() && 
                best_times[flight.destination_airport] <= next_arrival_time) {
                continue;
            }
            
            // Update best arrival time for destination airport
            best_times[flight.destination_airport] = next_arrival_time;
            
            // Create new node for this flight
            ItineraryNode next_node = current_node;
            next_node.itinerary.flights.push_back(flight);
            next_node.arrival_time = next_arrival_time;
            next_node.current_airport = flight.destination_airport;
            next_node.heuristic = estimate_time_to_destination(flight.destination_airport, destination_airport);
            
            queue.push(next_node);
        }
    }
    
    return false;
}

int TravelPlanner::estimate_time_to_destination(const std::string& source_airport, const std::string& destination_airport) const {
    if (source_airport == destination_airport) {
        return 0;
    }
    
    double distance;
    if (airport_db.get_distance(source_airport, destination_airport, distance)) {
        // Estimate time based on ~500 mph average speed
        return static_cast<int>(distance * 3600 / 500);
    }
    
    // Conservative heuristic for key airports in our route
    if (destination_airport == "PTU") {
        if (source_airport == "HHR") return 20000;
        if (source_airport == "CLD") return 18000;
        if (source_airport == "COS") return 16000;
        if (source_airport == "DEN") return 14000;
        if (source_airport == "SEA") return 10000;
        if (source_airport == "ANC") return 5000;
        if (source_airport == "BET") return 1000;
    }
    
    // Default heuristic for other airports
    return 10000;
}