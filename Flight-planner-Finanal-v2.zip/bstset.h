#ifndef BSTSET_H
#define BSTSET_H

template <typename T>
class BSTSet {
private:
    struct Node {
        T value;
        Node* left;
        Node* right;
        Node* parent;
        
        Node(const T& val, Node* p = nullptr) 
            : value(val), left(nullptr), right(nullptr), parent(p) {}
    };

    Node* root;
    
    void clear(Node* node) {
        if (node == nullptr) return;
        clear(node->left);
        clear(node->right);
        delete node;
    }

public:
    BSTSet() : root(nullptr) {}
    
    ~BSTSet() {
        clear(root);
    }

    class SetIterator {
    private:
        Node* current_;
        
        Node* find_min(Node* node) {
            if (!node) return nullptr;
            while (node->left) node = node->left;
            return node;
        }
        
    public:
        SetIterator(Node* node = nullptr) : current_(node) {}
        
        const T* get_and_advance() {
            if (!current_) return nullptr;
            
            const T* value = &current_->value;
            
            // If right child exists, find minimum in right subtree
            if (current_->right) {
                current_ = find_min(current_->right);
                return value;
            }
            
            // No right child, move up until we come from a left child
            Node* parent = current_->parent;
            while (parent && current_ == parent->right) {
                current_ = parent;
                parent = parent->parent;
            }
            current_ = parent;
            return value;
        }
    };

    void insert(const T& value) {
        if (!root) {
            root = new Node(value);
            return;
        }
        
        Node* curr = root;
        Node* parent = nullptr;
        
        while (curr) {
            parent = curr;
            
            if (value < curr->value) {
                curr = curr->left;
            } else if (curr->value < value) {
                curr = curr->right;
            } else {
                // Value already exists, replace it
                curr->value = value;
                return;
            }
        }
        
        if (value < parent->value) {
            parent->left = new Node(value, parent);
        } else {
            parent->right = new Node(value, parent);
        }
    }

    SetIterator find(const T& value) const {
        Node* curr = root;
        while (curr) {
            if (value < curr->value) {
                curr = curr->left;
            } else if (curr->value < value) {
                curr = curr->right;
            } else {
                return SetIterator(curr);
            }
        }
        return SetIterator(nullptr);
    }

    SetIterator find_first_not_smaller(const T& value) const {
        Node* curr = root;
        Node* result = nullptr;
        
        while (curr) {
            if (!(curr->value < value)) {
                result = curr;
                curr = curr->left;
            } else {
                curr = curr->right;
            }
        }
        
        return SetIterator(result);
    }
};

#endif