#ifndef TP_H
#define TP_H

#include "provided.h"
#include "fm.h"
#include "airport_db.h"
#include <string>
#include <set>

class TravelPlanner : public TravelPlannerBase {
public:
    TravelPlanner(const FlightManagerBase& flight_manager, const AirportDB& airport_db)
        : flight_manager(flight_manager), airport_db(airport_db) {}
    
    void add_preferred_airline(const std::string& airline);
    bool plan_travel(const std::string& source_airport, const std::string& destination_airport, 
                    int start_time, Itinerary& itinerary) const;

private:
    const FlightManagerBase& flight_manager;
    const AirportDB& airport_db;
    std::set<std::string> preferred_airlines;
    
    int estimate_time_to_destination(const std::string& source_airport, const std::string& destination_airport) const;
};

#endif