#include "fm.h"
#include <fstream>
#include <sstream>
#include <iostream>

bool FlightManager::load_flight_data(const std::string& filename) {
    std::ifstream file(filename);
    if (!file.is_open()) return false;

    std::string line;
    while (std::getline(file, line)) {
        if (line.empty() || line[0] == '/') continue;

        std::stringstream ss(line);
        std::string airline_name, source_airport, destination_airport;
        std::string flight_number_str, departure_time_str, arrival_time_str, duration_str;

        std::getline(ss, airline_name, ',');
        std::getline(ss, flight_number_str, ',');
        std::getline(ss, source_airport, ',');
        std::getline(ss, destination_airport, ',');
        std::getline(ss, departure_time_str, ',');
        std::getline(ss, arrival_time_str, ',');
        std::getline(ss, duration_str);

        try {
            FlightSegment flight;
            flight.airline_name = airline_name;
            flight.flight_number = std::stoi(flight_number_str);
            flight.source_airport = source_airport;
            flight.destination_airport = destination_airport;
            flight.departure_time = std::stoi(departure_time_str);
            flight.duration = std::stoi(duration_str);

            airport_flights[flight.source_airport].insert(flight);
        } catch (const std::exception&) {
            continue;
        }
    }
    file.close();
    return true;
}

std::vector<FlightSegment> FlightManager::find_flights(const std::string& source_airport, int start_time, int end_time) const {
    std::vector<FlightSegment> result;
    
    auto it = airport_flights.find(source_airport);
    if (it == airport_flights.end()) return result;
    
    FlightSegment dummy;
    dummy.departure_time = start_time;
    dummy.flight_number = 0;
    
    auto iter = it->second.find_first_not_smaller(dummy);
    const FlightSegment* flight;
    
    while ((flight = iter.get_and_advance()) != nullptr) {
        if (flight->departure_time >= end_time) break;
        result.push_back(*flight);
    }
    
    return result;
}