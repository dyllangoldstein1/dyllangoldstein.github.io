#include "fm.h"
#include "tp.h"
#include "airport_db.h"
#include <iostream>
#include <string>
#include <ctime>
#include <iomanip>
#include <sstream>

std::string format_timestamp(int timestamp) {
    std::time_t t = timestamp;
    std::tm* timeinfo = std::gmtime(&t);
    
    std::stringstream ss;
    ss << std::put_time(timeinfo, "%Y-%m-%d %H:%M:%S UTC");
    return ss.str();
}

int main() {
    // Load flight data
    FlightManager fm;
    if (!fm.load_flight_data("flights.txt")) {
        std::cerr << "Failed to load flight data." << std::endl;
        return 1;
    }
    std::cout << "Flight data loaded successfully." << std::endl;
    
    AirportDB adb;
    TravelPlanner tp(fm, adb);
    
    // Set travel constraints - THIS IS THE KEY FIX!
    tp.set_max_duration(86400);     // 24 hours
    tp.set_max_layover(10000);      // ~2.8 hours to allow SEA->ANC layover
    tp.set_min_connection_time(3600); // 1 hour connection time
    
    // Prompt for preferred airlines
    std::cout << "Do you want to specify preferred airlines? (y/n): ";
    char choice;
    std::cin >> choice;
    
    if (choice == 'y' || choice == 'Y') {
        std::cout << "Enter airlines (one per line, empty line to finish):" << std::endl;
        std::string airline;
        std::cin.ignore(); // Clear the newline
        
        while (true) {
            std::getline(std::cin, airline);
            if (airline.empty()) break;
            tp.add_preferred_airline(airline);
        }
    }
    
    // Get source and destination airports
    std::string source, destination;
    std::cout << "Enter source airport code: ";
    std::cin >> source;
    std::cout << "Enter destination airport code: ";
    std::cin >> destination;
    
    // Get departure time
    int departure_time;
    std::cout << "Use current time as departure time? (y/n): ";
    std::cin >> choice;
    
    if (choice == 'y' || choice == 'Y') {
        departure_time = std::time(nullptr);
    } else {
        std::cout << "Enter departure time (Unix timestamp): ";
        std::cin >> departure_time;
    }
    
    // Plan the travel
    std::cout << "Planning travel from " << source << " to " << destination
              << " starting at timestamp " << departure_time << std::endl;
    
    Itinerary itinerary;
    if (tp.plan_travel(source, destination, departure_time, itinerary)) {
        std::cout << "\nItinerary found!" << std::endl;
        std::cout << "Source: " << itinerary.source_airport << ", Destination: " 
                  << itinerary.destination_airport << ", Total Duration: " 
                  << (itinerary.total_duration / 3600.0) << " hours" << std::endl;
                  
        std::cout << "Arriving at source airport at: " << format_timestamp(departure_time) << std::endl;
        
        int current_time = departure_time;
        for (const auto& flight : itinerary.flights) {
            int wait_time = flight.departure_time - current_time;
            
            if (current_time == departure_time) {
                std::cout << "Wait time at initial airport: " << (wait_time / 3600.0) << " hours" << std::endl;
            } else {
                std::cout << "Layover: " << (wait_time / 3600.0) << " hours" << std::endl;
            }
            
            std::cout << "  " << flight.source_airport << " -> " << flight.destination_airport 
                      << ", Airline: " << flight.airline_name 
                      << ", Departure: " << format_timestamp(flight.departure_time) 
                      << ", Arrival: " << format_timestamp(flight.departure_time + flight.duration)
                      << ", Duration: " << (flight.duration / 3600.0) << " hours" << std::endl;
            
            current_time = flight.departure_time + flight.duration;
        }
        
        std::cout << "Arriving at destination airport at: " << format_timestamp(current_time) << std::endl;
    } else {
        std::cout << "No valid itinerary found." << std::endl;
    }

    return 0;
}