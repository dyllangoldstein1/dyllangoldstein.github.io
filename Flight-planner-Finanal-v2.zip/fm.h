#ifndef FM_H
#define FM_H

#include "bstset.h"
#include "provided.h"
#include <string>
#include <vector>
#include <map>
#include <fstream>
#include <sstream>

// Comparison operator for FlightSegment
inline bool operator<(const FlightSegment& lhs, const FlightSegment& rhs) {
    if (lhs.departure_time != rhs.departure_time)
        return lhs.departure_time < rhs.departure_time;
    return lhs.flight_number < rhs.flight_number;
}

class FlightManager : public FlightManagerBase {
public:
    bool load_flight_data(const std::string& filename) override;
    std::vector<FlightSegment> find_flights(const std::string& source_airport, 
                                           int start_time, int end_time) const override;

private:
    std::map<std::string, BSTSet<FlightSegment>> airport_flights;
};

#endif